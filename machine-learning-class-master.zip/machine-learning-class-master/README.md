machine-learning-class
====

This project contains my code for the programming exercises in the Stanford
University Machine Learning class on Coursera.

https://www.coursera.org/course/ml

### Usage

All code was developed and tested on Octave 3.4.0.

http://www.gnu.org/software/octave/
